﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Realtor
    {
        //Properties Go Here
        private string _FirstName;
        public string FirstName { get; set; }

        private string _LastName;
        public string LastName { get; set; }

        private string _OfficeStreetName;
        public string OfficeStreetName { get; set; }

        private ushort _OfficeNumber;
        public ushort OfficeNumber { get; set; }

        private ushort _OfficeZipCode;
        public ushort OfficeZipCode { get; set; }

        //Methods Go Here
      
    }
}
